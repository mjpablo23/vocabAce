//
//  ViewController.h
//  vocabAce
//
//  Created by Paul Yang on 8/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "cardViewController.h"

@interface ViewController : UIViewController

@property (nonatomic, retain) IBOutlet UIButton *cardButton;

-(IBAction) presentCardViewController;

@end
