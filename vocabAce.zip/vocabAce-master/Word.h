//
//  Word.h
//  vocabAce
//
//  Created by Paul Yang on 9/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface Word : NSObject {
    sqlite3 *database;
    BOOL dirty;
}

-(id)initWithName:(NSString *)wd  
       speechPart:(NSString*)sp  
         defShort:(NSString *)defShort  
          defLong:(NSString *)defLong 
         synonyms:(NSString *)synString  
         antonyms:(NSString *)antString  
            notes:(NSString *)noteStr   
       difficulty:(NSInteger)diff   
      timesViewed:(NSInteger)tv 
           setNum:(int)setNum 
           realPK:(int)real_pk
      database_sq:(sqlite3 *)db;

@property (nonatomic, retain) NSString *word;
@property (nonatomic, retain) NSString *speechPart;
@property (nonatomic, retain) NSString *defShort;
@property (nonatomic, retain) NSString *defLong;
@property (nonatomic, retain) NSString *synString; 
@property (nonatomic, retain) NSString *antString; 
@property (nonatomic, retain) NSString *noteStr;
@property (nonatomic, retain) NSNumber *setNumber;
@property (nonatomic, retain) NSMutableArray *translationArray;
@property int diff;
@property int timesViewed;
@property int aPK;

-(NSString *) getDefText:(int)useShortDef;
-(NSString *) getSynonyms;
-(NSString *) getSynText: (NSArray *) synParts num_syns_for_loop:(int) numSynsForLoop;

@end
