//
//  LanguagePickerViewController.h
//  vocabAce
//
//  Created by Paul Yang on 9/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "languageModel.h"

@interface LanguagePickerViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource> {
    
}

@property (nonatomic, retain) IBOutlet UIPickerView *picker;
@property (nonatomic, retain) IBOutlet UIButton *doneButton;
@property (nonatomic, retain) NSArray *languagesArray;
-(IBAction) doneButtonPressed:(id)sender;

@end
