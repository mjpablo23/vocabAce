//
//  setHashObject.m
//  vocabAce
//
//  Created by Paul Yang on 9/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "setHashObject.h"

@implementation setHashObject
@synthesize setNumber, startIndexInWordArray, numWordsInSet;

-(id) init {
    [super init];
    return self;
}

-(id) initWithItems:(NSNumber *) setNumber numWords:(NSNumber *)numWords startIndex:(NSNumber*) startIndex {
    [super init];
    self.setNumber = setNumber;
    self.startIndexInWordArray = startIndex;
    self.numWordsInSet = numWords;
    return self;
}

@end
