//
//  stateModel.h
//  vocabAce
//
//  Created by Paul Yang on 8/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface stateModel : NSObject

@property int coverVisible;
@property int hintTextViewVisible;
@property int showingLongDefinition;

@end
