//
//  cardViewController.h
//  vocabAce
//
//  Created by Paul Yang on 8/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "Word.h"
#import "OptionsViewController.h"
#import "SetWordListViewController.h"

@interface cardViewController : UIViewController <UIGestureRecognizerDelegate, UIActionSheetDelegate, UITextViewDelegate> {
    CGSize frameSize;
    
    AppDelegate *appDelegate;
    Word *currentWord;

    int messageBarHeight;
    int definitionTextViewHeight;
    int translationTextViewHeight;
    int translationTextViewWidth;
    int synonymTextViewHeight;
    int synonymTextViewWidth;
    int nextWordButtonHeight;
    int nextWordButtonWidth;
    int currentWordButtonWidth;
    int currentWordButtonHeight;
    
    int coverViewHeight;
    int hintTextViewHeight;
    int hintDoneButtonHeight;
    int hintDoneButtonWidth;
}

// navigation bar
@property (nonatomic, retain) IBOutlet UIBarButtonItem *soundButton;

// message view (vocab word)
@property (nonatomic, retain) IBOutlet UIView *messageView;
@property (nonatomic, retain) IBOutlet UILabel *messageLabel;

// toolbar
@property (nonatomic, retain) IBOutlet UIBarButtonItem *optionsButton;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *starButton;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *levelButton;

@property (nonatomic, retain) IBOutlet UISegmentedControl *toolbarSegmentedControl;
-(void) changeDefinitionType:(UISegmentedControl *) segmentedControl;
-(UISegmentedControl *) definitionLengthSegmentedControl;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *toolbarSegmentedControlButton; 

@property (nonatomic, retain) IBOutlet UIBarButtonItem *flexibleSpace;

//navigation buttons
@property (nonatomic, retain) IBOutlet UIButton *nextWordButton; 
-(void) loadNextWordButton; 
-(void) nextWordButtonPressed;

@property (nonatomic, retain) IBOutlet UIButton *currentWordButton;
-(void) loadWordButton; 
-(void) currentWordButtonPressed;
-(void) bringUpHintTextView;
-(void) hideHintTextView;

// definitions
@property (nonatomic, retain) IBOutlet UITextView *definitionTextView;
@property (nonatomic, retain) IBOutlet UITextView *translationTextView;
@property (nonatomic, retain) IBOutlet UITextView *synonymTextView;
// cover
-(void) handleTap:(int) num;
@property (nonatomic, retain) IBOutlet UIView *coverView;
@property (nonatomic, retain) IBOutlet UITextView *hintTextView;

-(void) loadNavigationBar;
-(void) loadMessageBar;
-(void) loadToolbar; 
-(void) loadDefinitionTextView;
-(void) loadTranslationTextView;
-(void) loadCover;
-(void) loadContent;
-(void) resizeDefinitionView;

-(void) pressHintDoneButton:(int) num;
@property (nonatomic, assign) IBOutlet UIButton *hintDoneButton;
@property (nonatomic, assign) IBOutlet UIView *accessoryView;

// toolbar action sheeets
-(void) openOptionsMenu;
- (IBAction) levelAction:(id)sender;
- (IBAction) starAction:(id)sender;
@property (nonatomic, retain) IBOutlet UIActionSheet *levelActionSheet;
@property (nonatomic, retain) IBOutlet UIActionSheet *starActionSheet;
-(void) handleLevelActionSheet:(NSInteger) buttonIndex;
-(void) handleStarActionSheet:(NSInteger) buttonIndex;

// load next word
-(void) setCurrentWord;

// loading data 
-(void) loadLongDefinition;
-(void) loadShortDefinition;

// -(void) dismissOptionsPopoverController;

@end
