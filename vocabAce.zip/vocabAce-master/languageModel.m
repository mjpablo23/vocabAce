//
//  languageModel.m
//  vocabAce
//
//  Created by Paul Yang on 9/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "languageModel.h"

@implementation languageModel

@synthesize languageArray;

-(id) init {
    [super init];
    
    // languageArray = [[NSMutableArray alloc] initWithObjects:@"Chinese (Traditional): 中文", @"Chinese (Simplified): 中文", @"Korean: 한국어", @"Arabic: العربية", @"Japanese: 日本語", @"Hindi: हिन्दी", @"Hebrew: עברית", @"French: française", @"Spanish: español", @"German: Deutsch", nil]; 
    
    //languageArray = [[NSMutableArray alloc] initWithObjects:@"Chinese (Traditional): 中文", @"Spanish: español", nil]; 
    languageArray = [languageModel getLanguagesArray];
    return self;
}

+(NSArray *) getLanguagesArray {
    NSMutableArray *array = [[NSMutableArray alloc] initWithObjects:@"Chinese (Traditional): 中文", @"Spanish: español", nil]; 
    return [array autorelease];
}

-(NSArray *) getTranslationArray:(int) languageIndex {
    
    NSString *filePath, *fileName;
    
    switch (languageIndex) {
        case 0:
            fileName = @"sat_chinese_wordOnly_v2";
            break;
        case 1:
            fileName = @"sat_spanish_wordOnly_v2";
            break;
        default:
            break;
    }
    
    filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"txt"];
    
    NSString *translation = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    
    NSArray *translatedWords = [translation componentsSeparatedByString:@"\n"];
    NSLog(@"translation small file: \nfirst word: %@ \n10th word: %@", [translatedWords objectAtIndex:0], [translatedWords objectAtIndex:9]);
    
    return translatedWords;
}

@end
