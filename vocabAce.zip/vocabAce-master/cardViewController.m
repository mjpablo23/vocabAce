//
//  cardViewController.m
//  vocabAce
//
//  Created by Paul Yang on 8/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "cardViewController.h"

@interface cardViewController ()

@end

@implementation cardViewController

@synthesize messageView, messageLabel, optionsButton, starButton, levelButton, flexibleSpace, soundButton, definitionTextView, synonymTextView, translationTextView, coverView, hintTextView, nextWordButton, currentWordButton, toolbarSegmentedControl, toolbarSegmentedControlButton, levelActionSheet, starActionSheet, hintDoneButton, accessoryView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

// load the various text views to add to the main view
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    [self setCurrentWord];
    
    [self setViewSizes];
    
    [self loadNavigationBar];

    // the vocab word is in the message bar
    [self loadMessageBar];

    [self loadToolbar];
    
    [self loadDefinitionTextView];
    
    [self loadSynonymTextView];
    [self loadTranslationTextView];

    [self loadNextWordButton];
    [self loadWordButton];
    
    [self loadCover];
    
    // load contents such as the word, definition, translation, etc.
    [self loadContent];
    
}

// load content needs to be called on viewWillAppear
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSLog(@"cardViewController::viewWillAppear called");
    [self loadContent];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

# pragma mark view sizes
// text views are programmatically sized, not using interface builder
-(void) setViewSizes {
    // total height of frame is 480 with status bar, 460 without status bar
    // total width of frame is 320
    // total height of nav bar is 44
    // total height of toolbar is ~40
    messageBarHeight = 60;
    definitionTextViewHeight = 140;
    translationTextViewHeight = 60;
    translationTextViewWidth = 320;
    synonymTextViewHeight = 60;
    synonymTextViewWidth = 320;    
    nextWordButtonHeight = 60;
    nextWordButtonWidth = 160;
    currentWordButtonWidth = 320 - nextWordButtonWidth;
    currentWordButtonHeight = nextWordButtonHeight;
    
    coverViewHeight = definitionTextViewHeight + synonymTextViewHeight + translationTextViewHeight;
    hintDoneButtonHeight = 30;
    hintDoneButtonWidth = 60;
    hintTextViewHeight = 110;
}

# pragma mark load initial word

-(void) loadNavigationBar {
    [self.navigationController setNavigationBarHidden:YES];
    
    // sound button not used
    soundButton = [[[UIBarButtonItem alloc] initWithTitle:@"sound" style:UIBarButtonItemStyleBordered target:self action:@selector(openOptionsMenu)] autorelease];
    
    // do not display the sound button since it's not yet implemented
    // self.navigationItem.rightBarButtonItem = soundButton;
}

// not used
-(void) loadMessageBar {
    // the messageView contains the vocab word, is at the top
    self.messageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 60)];
    [messageView setBackgroundColor:[UIColor greenColor]];
    //[self.messageView setAlpha:0.8];
    [self.view addSubview:self.messageView];
    
    messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 60)];
    [messageLabel setFont:[UIFont boldSystemFontOfSize:18]];
    [messageLabel setTextAlignment:UITextAlignmentCenter];
    [messageLabel setBackgroundColor:[UIColor clearColor]];
    [messageLabel setTextColor:[UIColor blackColor]];
    messageLabel.adjustsFontSizeToFitWidth = YES;
    messageLabel.minimumFontSize = 8; 
    messageLabel.numberOfLines = 1;
    
    [self.messageView addSubview:messageLabel];
}

// toolbar contains options and segmented control
-(void) loadToolbar {
    [self.navigationController setToolbarHidden:NO];
    [self.navigationController.toolbar setBarStyle:UIBarStyleDefault];
    
    // flexible space for toolbar
    flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    // options button for choosing language
    optionsButton = [[[UIBarButtonItem alloc] initWithTitle:@"options" style:UIBarButtonItemStyleBordered target:self action:@selector(openOptionsMenu)] autorelease];
    
    // not used
    starButton = [[[UIBarButtonItem alloc] initWithTitle:@"star" style:UIBarButtonItemStyleBordered target:self action:@selector(starAction:)] autorelease];
    
    // not used
    levelButton = [[[UIBarButtonItem alloc] initWithTitle:@"level" style:UIBarButtonItemStyleBordered target:self action:@selector(levelAction:)] autorelease];
    
    toolbarSegmentedControl = [self definitionLengthSegmentedControl];
    toolbarSegmentedControlButton = [[UIBarButtonItem alloc] initWithCustomView:toolbarSegmentedControl];
    
//    [self setToolbarItems:[NSArray arrayWithObjects:optionsButton, flexibleSpace, starButton, flexibleSpace, toolbarSegmentedControlButton, flexibleSpace, levelButton, nil]];
    [self setToolbarItems:[NSArray arrayWithObjects:optionsButton, flexibleSpace, toolbarSegmentedControlButton, nil]];
    [flexibleSpace release];
    
    NSLog(@"toolbar height is: %f", self.navigationController.toolbar.frame.size.height);
}

// load text view for definition
-(void) loadDefinitionTextView {
    // y position is under the message bar
    definitionTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, messageBarHeight, 320, definitionTextViewHeight)];
    definitionTextView.editable = NO;
    definitionTextView.backgroundColor = [UIColor yellowColor];
    definitionTextView.scrollEnabled = YES;

    // set font type and font size
    UIFont *defFont = [UIFont fontWithName:@"Verdana" size:16];
    [definitionTextView setFont:defFont];
    
    // add definition text view as subview to main view
    [self.view addSubview:self.definitionTextView];
}

-(void) loadTranslationTextView {
    // y position is function of other text view heights
    int translationTextViewYPosition = messageBarHeight + definitionTextViewHeight + synonymTextViewHeight;
    translationTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, translationTextViewYPosition, translationTextViewWidth, translationTextViewHeight)];
    
    translationTextView.backgroundColor = [UIColor redColor];
    translationTextView.editable = NO;
    
    // set font type and font size
    UIFont *defFont = [UIFont fontWithName:@"Verdana" size:16];
    [translationTextView setFont:defFont];
    
    // add translation text view to main view
    [self.view addSubview:self.translationTextView];
}

-(void) loadSynonymTextView {
    // y position is function of other text view heights
    int synonymTextViewYPosition = messageBarHeight + definitionTextViewHeight;
    synonymTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, synonymTextViewYPosition, synonymTextViewWidth, synonymTextViewHeight)];
    
    synonymTextView.backgroundColor = [UIColor whiteColor];
    synonymTextView.editable = NO;
    
    UIFont *defFont = [UIFont fontWithName:@"Verdana" size:16];
    [synonymTextView setFont:defFont];
    
    [self.view addSubview:self.synonymTextView];
}

// load button for next word
-(void) loadNextWordButton {
    // y position is function of other text view heights
    int yPosition = messageBarHeight + definitionTextViewHeight + synonymTextViewHeight + translationTextViewHeight;
    nextWordButton = [[UIButton alloc] initWithFrame:CGRectMake(currentWordButtonWidth, yPosition, nextWordButtonWidth, nextWordButtonHeight)];
    [nextWordButton addTarget:self action:@selector(nextWordButtonPressed) forControlEvents:UIControlEventTouchUpInside];
    [nextWordButton setBackgroundColor:[UIColor orangeColor]];
    [nextWordButton setTitle:@"next word" forState:UIControlStateNormal];
    [self.view addSubview:nextWordButton];
}

-(void) loadWordButton {
    int yPosition = messageBarHeight + definitionTextViewHeight + synonymTextViewHeight + translationTextViewHeight;
    currentWordButton = [[UIButton alloc] initWithFrame:CGRectMake(0, yPosition, currentWordButtonWidth, currentWordButtonHeight)];
    [currentWordButton addTarget:self action:@selector(currentWordButtonPressed) forControlEvents:UIControlEventTouchUpInside];
    [currentWordButton setBackgroundColor:[UIColor brownColor]];
    NSString *wd = currentWord.word;
    [currentWordButton setTitle:wd forState:UIControlStateNormal];
    [self.view addSubview:currentWordButton];
}

// loads the "cover" over the vocabulary word and definitions so the user can try to recall the definition on their own
-(void) loadCover {
    // initialize and set the background color for the cover
    self.coverView = [[UIView alloc] initWithFrame:CGRectMake(0, messageBarHeight, 320, coverViewHeight)];
    [coverView setBackgroundColor:[UIColor greenColor]];
    
    UIFont *defFont = [UIFont fontWithName:@"Verdana" size:16];
    
    // initialize the hint text view and define properties (not currently used)
    hintTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, 480, coverView.frame.size.width, hintTextViewHeight)];
    hintTextView.delegate = self;    
    hintTextView.text = @""; 
    hintTextView.textColor = [UIColor whiteColor];
    hintTextView.backgroundColor = [UIColor grayColor];
    hintTextView.editable = YES;
    [hintTextView setFont:defFont];
    
    // add the hint text view as a subview of the cover view
    [coverView addSubview:hintTextView];
    [hintTextView release];
    
    // initialize the text view telling the user to tap the cover to dismiss the hint
    UITextView *noteView = [[UITextView alloc] initWithFrame:
                            CGRectMake(10, 10, 320, 60)];
//                            CGRectMake(10, coverViewHeight-60, 320, 60)];
    noteView.text = @"tap to uncover or cover definition";
    noteView.textColor = [UIColor blackColor];
    noteView.backgroundColor = [UIColor greenColor];
    noteView.editable = NO;
    [noteView setFont:defFont];
    [coverView addSubview:noteView];
    [noteView release];
    
    // add gesture recognizer to the cover view so it will dismiss when tapped
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    tapRecognizer.delegate = self;
    [self.coverView addGestureRecognizer:tapRecognizer];
    [tapRecognizer release];
    
    // add the cover view to the main view
    [self.view addSubview:self.coverView];
    
    appDelegate.viewStateModel.coverVisible = 1;
    appDelegate.viewStateModel.hintTextViewVisible = 1;
}

// use this segmented control in the toolbar to choose whether to display the short or long definition
-(UISegmentedControl *) definitionLengthSegmentedControl {
    UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:nil];
    [segmentedControl insertSegmentWithTitle:@"short definition" atIndex:0 animated:NO];
    [segmentedControl insertSegmentWithTitle:@"long definition" atIndex:1 animated:NO];
    segmentedControl.segmentedControlStyle = UISegmentedControlStyleBar;
    [segmentedControl addTarget:self action:@selector(changeDefinitionType:) forControlEvents:UIControlEventValueChanged];
    segmentedControl.selectedSegmentIndex = 0; // select distance by default
    return [segmentedControl autorelease];
}

// action from changing between short and long definitions in the segmented control
-(void) changeDefinitionType:(UISegmentedControl *) segmentedControl {
    //NSLog(@"definition type selected index: %d", segmentedControl.selectedSegmentIndex);
    [self resizeDefinitionView];
    switch (segmentedControl.selectedSegmentIndex) {
        case 0:
            // if index 0 selected, load the short definition
            NSLog(@"short mode");
            [self loadShortDefinition];
            break;
        case 1:
            // index 1 selected, load long definition
            NSLog(@"long mode");
            [self loadLongDefinition];
            break;
        default:
            break;
    }
}

-(void) setCurrentWord {
    currentWord = [appDelegate.wordDataModel getCurrentWord];
}

-(void) loadLongDefinition {
    // definitionTextView.text = currentWord.defLong;
    definitionTextView.text = [currentWord getDefText:0];
}

-(void) loadShortDefinition {
    // definitionTextView.text = currentWord.defShort;
    definitionTextView.text = [currentWord getDefText:1];
}

# pragma mark action sheets
// not used
- (IBAction) levelAction:(id)sender
{
	levelActionSheet = [[[UIActionSheet alloc] initWithTitle:@"Choose word difficulty"
                                                            delegate:self cancelButtonTitle:@"Cancel"
                                              destructiveButtonTitle:nil
                                                   otherButtonTitles:	@"Hard",
                                 @"Medium", @"Easy", @"Discard",
                                 nil,
                                 nil] autorelease];
	
	// use the same style as the nav bar
	// styleAlert.actionSheetStyle = self.navigationController.navigationBar.barStyle;
	
	[levelActionSheet showFromToolbar:self.navigationController.toolbar];
	//[levelAlert release];
}

// not used
- (IBAction) starAction:(id)sender
{
	starActionSheet = [[[UIActionSheet alloc] 
                        initWithTitle:@"Choose action"
                        delegate:self 
                        cancelButtonTitle:@"Cancel"
                        destructiveButtonTitle:nil
                        otherButtonTitles:
                         @"Start slideshow", @"View word list for set",
                        nil,
                        nil] autorelease];
	
	// use the same style as the nav bar
	// styleAlert.actionSheetStyle = self.navigationController.navigationBar.barStyle;
	
	[starActionSheet showFromToolbar:self.navigationController.toolbar];
	//[levelAlert release];
}

// not used
- (void)actionSheet:(UIActionSheet *)modalView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (modalView == levelActionSheet) {
        NSLog(@"level action sheet pressed with index: %d", buttonIndex);
        [self handleLevelActionSheet:buttonIndex];
    }
    else if (modalView == starActionSheet) {
        NSLog(@"star action sheet pressed with index: %d", buttonIndex);
        [self handleStarActionSheet:buttonIndex];
    }
}    

// not used
-(void) handleLevelActionSheet:(NSInteger) buttonIndex
{
    int newSet = 0;
    // Change the navigation bar style, also make the status bar match with it
    switch (buttonIndex) {
        case 0:
            NSLog(@"hard level button");
            // hard levels: 8 to 10
            newSet = [appDelegate.wordDataModel getSetIndex:3];
            break;
        case 1:
            NSLog(@"medium level button");
            // medium levels: 4 to 7
            newSet = [appDelegate.wordDataModel getSetIndex:2];
            break;
        case 2:
            NSLog(@"easy level button");
            // easy levels: 1 to 3
            newSet = [appDelegate.wordDataModel getSetIndex:1];
            break;
        case 3:
            NSLog(@"discard button");
            newSet = [appDelegate.wordDataModel getSetIndex:0];;
            break;
        default:
            NSLog(@"default, returning from actionsheet");
            return;
            break;
    }
    [appDelegate.wordDataModel changeSetsForCurrentWord:newSet];                
    [self nextWordButtonPressed];
    [appDelegate.wordDataModel printSetData:appDelegate.wordDataModel.currentSetIndex];
    [appDelegate.wordDataModel printSetData:newSet];
}

// not used
-(void) handleStarActionSheet:(NSInteger) buttonIndex
{
    // Change the navigation bar style, also make the status bar match with it
	switch (buttonIndex)
	{
		case 0:
		{
            NSLog(@"Start slideshow");
			break;
		}
		case 1:
		{
            NSLog(@"View word list for set");
            SetWordListViewController *setListView = [[SetWordListViewController alloc] initWithNibName:@"SetWordListViewController" bundle:nil];
            [self.navigationController pushViewController:setListView animated:YES];
            [setListView release];
			break;
		}
		case 2:
		{
			
			break;
		}
	}
}

# pragma mark handle cover related actions
// this will toggle the cover up and down
-(void) handleTap:(int) num {
    NSLog(@"tap detected on coverView");
    
    if (appDelegate.viewStateModel.coverVisible == 1) {
        // animation to move cover down, uncovering the definition, synonyms, translation
        [UIView animateWithDuration:0.25
                              delay:0.0 options:UIViewAnimationCurveEaseInOut
                         animations:^{
                             [self.coverView setFrame:CGRectMake(0, 380, self.coverView.frame.size.width, self.coverView.frame.size.height)];
                         }
                         completion:nil];
        // set coverVisible to 0, but part of it will still be showing
        appDelegate.viewStateModel.coverVisible = 0;
    }
    else {
        // animation to move cover back up, covering the definition, synonyms, translation
        [UIView animateWithDuration:0.25
                              delay:0.0 options:UIViewAnimationCurveEaseInOut
                         animations:^{
                             [self.coverView setFrame:CGRectMake(0, 60, self.coverView.frame.size.width, self.coverView.frame.size.height)];
                         }
                         completion:nil];
        // set coverVisible to 1 to cover up the definition, etc back up
        appDelegate.viewStateModel.coverVisible = 1;
        
    }
}

// not used
-(void) pressHintDoneButton:(int) num {
    [hintTextView resignFirstResponder];
}
    
#pragma mark Text view delegate methods

// not used
- (BOOL)textViewShouldBeginEditing:(UITextView *)aTextView {
    NSLog(@"calling textViewShouldBeginEditing");
    if (hintTextView.inputAccessoryView == nil) {
        accessoryView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, hintDoneButtonHeight)];
        accessoryView.backgroundColor = [UIColor purpleColor];
        int hintOffset = 320 - hintDoneButtonWidth - 10;
        hintDoneButton = [[UIButton alloc] initWithFrame:CGRectMake(hintOffset, 0, hintDoneButtonWidth, hintDoneButtonHeight)];
        [hintDoneButton addTarget:self action:@selector(pressHintDoneButton:) forControlEvents:UIControlEventTouchUpInside];
        hintDoneButton.backgroundColor = [UIColor blueColor];
        [hintDoneButton setTitle:@"done" forState:UIControlStateNormal];
        [self.accessoryView addSubview:hintDoneButton];
        // Loading the AccessoryView nib file sets the accessoryView outlet.
        hintTextView.inputAccessoryView = accessoryView;    
        // After setting the accessory view for the text view, we no longer need a reference to the accessory view.
        self.accessoryView = nil;
    }
    return YES;
}

# pragma mark toolbar related button actions

-(void) openOptionsMenu {
    NSLog(@"opening options");
    OptionsViewController *optionsView = [[OptionsViewController alloc] init];
    [self presentModalViewController:optionsView animated:YES];
    [optionsView release];
}

# pragma mark load content
-(void) loadContent {
    
    // update the currentWord
    currentWord = [appDelegate.wordDataModel getCurrentWord];
    
    // set the word displayed in the current word button to the current word
    [currentWordButton setTitle:currentWord.word forState:UIControlStateNormal];
    
    messageLabel.text = currentWord.word;
    
    // set the text for synomyms
    NSString *synDes = @"Synonyms: ";
    NSString *synonymText = [synDes stringByAppendingString:[currentWord getSynonyms]];
    synonymTextView.text = synonymText;
    
    int languageIndex = [[NSUserDefaults standardUserDefaults] integerForKey:@"languageInd"];
    
    // use objectAtIndex to choose language
    NSString *translationDes = @"Translation: ";
    NSString *tranlation = [[currentWord translationArray] objectAtIndex:languageIndex];
    NSString *translationText = [translationDes stringByAppendingString:tranlation];
    translationTextView.text = translationText;
    NSString *navTitle = [NSString stringWithFormat:@"Set %d", [currentWord.setNumber intValue]];
    [self.navigationItem setTitle:navTitle];
    
    // get from segmented control whether it's a short or long definition
    int showLongDef = toolbarSegmentedControl.selectedSegmentIndex;
    NSString *defText;
    
    // set defText to the short or long definition, with description of short or long in front
    if (showLongDef == 1) {
        defText = [currentWord getDefText:0];
    }
    else {
        defText = [currentWord getDefText:1];
    }
    
    // set the text in the definition text view to defText
    definitionTextView.text = defText;
}

# pragma mark resize definition view
// when the long definition is selected, need to resize the text view for the definition so it is longer
// if short definition is selected, show the shorter definition
-(void) resizeDefinitionView {
    int showLongDef = toolbarSegmentedControl.selectedSegmentIndex;
    if (showLongDef == 1) {
        // show long definition by resizing the text view
        [UIView animateWithDuration:0.25 
                              delay:0.0 options:UIViewAnimationCurveEaseInOut 
                         animations:^{
                             [definitionTextView setFrame:CGRectMake(0, messageBarHeight, 320, definitionTextViewHeight + translationTextViewHeight + synonymTextViewHeight)];
                         }
                         completion:nil];
        // hide the translation and synonym views
        translationTextView.hidden = YES;
        synonymTextView.hidden = YES;
    }
    else {
        // show the translation and synonym views
        translationTextView.hidden = NO;
        synonymTextView.hidden = NO;
        // resize the text view
        [definitionTextView setFrame:CGRectMake(0, messageBarHeight, 320, definitionTextViewHeight)];
    }
}

# pragma mark word navigation actions
// pressing the next word button retreives the next word from the database and sets it to the current word
-(void) nextWordButtonPressed {
    NSLog(@"next word button pressed");
    
    [appDelegate.wordDataModel updateCurrentWord];
    currentWord = [appDelegate.wordDataModel getCurrentWord];
    
    synonymTextView.text = [currentWord getSynonyms];
    
    // after the current word is set, load the contents into the view
    [self loadContent];
    
    NSLog(@"setNumber for currentWord new: %d, PK: %d", [currentWord.setNumber intValue], currentWord.aPK);
}

-(void) currentWordButtonPressed {
    // toggle the cover when the current word button is pressed
    [self handleTap:0];
}

// not currently used
-(void) bringUpHintTextView {
    [UIView animateWithDuration:0.25 
                          delay:0.0 options:UIViewAnimationCurveEaseInOut 
                     animations:^{
                         [self.coverView setFrame:CGRectMake(0, messageBarHeight, self.coverView.frame.size.width, self.coverView.frame.size.height)];
                         [hintTextView setFrame:CGRectMake(0, 0, 320, hintTextViewHeight)];
                     }
                     completion:nil];
    
    appDelegate.viewStateModel.coverVisible = 1;
    appDelegate.viewStateModel.hintTextViewVisible = 1;
    [currentWordButton setTitle:@"hide hint" forState:UIControlStateNormal];
}

// not currently used
-(void) hideHintTextView {
    [UIView animateWithDuration:0.25 
                          delay:0.0 options:UIViewAnimationCurveEaseInOut 
                     animations:^{
                         [hintTextView setFrame:CGRectMake(0, 400, 320, hintTextViewHeight)];
                     }
                     completion:nil];
    appDelegate.viewStateModel.hintTextViewVisible = 0;
    [currentWordButton setTitle:@"view hint" forState:UIControlStateNormal];
}

# pragma mark gesture recognizer delegate
// tells whether gesture recognizers should be able to receive touch
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    // need to declare other buttons as outlets so they can be added to here
	if (touch.view == hintDoneButton) {
        return NO;
    }
    return YES;
}

@end
