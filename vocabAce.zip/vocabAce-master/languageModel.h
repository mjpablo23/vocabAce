//
//  languageModel.h
//  vocabAce
//
//  Created by Paul Yang on 9/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface languageModel : NSObject {
    
}

@property (nonatomic, retain) NSArray *languageArray;

-(NSArray *) getTranslationArray:(int) languageIndex;
+(NSArray *) getLanguagesArray;

@end
