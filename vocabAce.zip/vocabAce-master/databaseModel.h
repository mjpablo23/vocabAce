//
//  databaseModel.h
//  vocabAce
//
//  Created by Paul Yang on 9/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
#import "Word.h"
#import "setHashObject.h"
#import "languageModel.h"

@interface databaseModel : NSObject {
    sqlite3 *database;
	NSString *databaseName;
	NSString *databasePath;
    //NSDictionary *setMarkerTable;
}

@property (nonatomic, retain) NSMutableArray *wordArray;
@property (nonatomic, retain) NSMutableArray *setMarkerArray;
@property (nonatomic, retain) languageModel *languageData;
@property int currentWordArrayIndex;  // index of the current word in the wordArray
@property int currentSetIndex; // index of the current set

-(void) loadWords;
-(void) checkAndCreateDatabase;
-(void) readWordsFromDatabase;
-(Word *) getCurrentWord;
-(void) updateCurrentWord;
-(void) setCurrentWord:(int) wordIndex;
-(void) loadTranslations;
-(int) firstWordInSet:(int) setIndex;
-(int) randomWordInSet:(int) setIndex;
-(void) changeSetsForCurrentWord:(int) newSetIndex;
-(void) printSetData:(int) setNum;
-(int) getSetIndex:(int) difficultyIndicator;
-(float) randomUniformVar;

@end
