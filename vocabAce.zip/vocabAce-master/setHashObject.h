//
//  setHashObject.h
//  vocabAce
//
//  Created by Paul Yang on 9/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface setHashObject : NSObject

@property (nonatomic, retain) NSNumber *setNumber;
@property (nonatomic, retain) NSNumber *startIndexInWordArray;
@property (nonatomic, retain) NSNumber *numWordsInSet;

@end
