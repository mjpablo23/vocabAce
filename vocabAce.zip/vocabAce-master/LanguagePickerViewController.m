//
//  LanguagePickerViewController.m
//  vocabAce
//
//  Created by Paul Yang on 9/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "LanguagePickerViewController.h"

@interface LanguagePickerViewController ()

@end

@implementation LanguagePickerViewController

@synthesize picker, doneButton, languagesArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.languagesArray = [languageModel getLanguagesArray];
        NSLog(@"languagesArray[0] = %@", [languagesArray objectAtIndex:0]);
    }
    return self;
}

-(void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    int ind = [[NSUserDefaults standardUserDefaults] integerForKey:@"languageInd"];
    [picker selectRow:ind inComponent:0 animated:YES];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction) doneButtonPressed:(id)sender {
    NSInteger row = [picker selectedRowInComponent:0];
    NSLog(@"setting languageInd: %d", row);
    [[NSUserDefaults standardUserDefaults] setInteger:row forKey:@"languageInd"];
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark Picker Data Source Methods 
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView { 
    return 1; 
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component { 
    NSLog(@"numRowsInPicker: %d", [languagesArray count]);
    return [languagesArray count]; 
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component { 
    NSLog(@"picker selected language: %@", [languagesArray objectAtIndex:row]);
    return [languagesArray objectAtIndex:row]; 
}

@end
