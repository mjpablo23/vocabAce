//
//  AppDelegate.h
//  vocabAce
//
//  Created by Paul Yang on 8/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "stateModel.h"
#import "databaseModel.h"

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@property (nonatomic, retain) stateModel *viewStateModel;
@property (nonatomic, retain) databaseModel *wordDataModel; 

@end
