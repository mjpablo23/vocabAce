//
//  OptionsViewController.h
//  vocabAce
//
//  Created by Paul Yang on 9/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LanguagePickerViewController.h"

@interface OptionsViewController : UIViewController {
    
}

@property (nonatomic, retain) IBOutlet UIButton *languageButton;
@property (nonatomic, retain) IBOutlet UIButton *doneButton;

@end

