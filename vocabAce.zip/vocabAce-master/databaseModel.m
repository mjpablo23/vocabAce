//
//  databaseModel.m
//  vocabAce
//
//  Created by Paul Yang on 9/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "databaseModel.h"


@implementation databaseModel 

@synthesize wordArray, currentWordArrayIndex, languageData, currentSetIndex, setMarkerArray; 

- (id) init {
    [super init];
    databaseName = @"vocab_sat_9_7a.sql";    
    
    [self loadWords];
    
    return self;
}

// load words from sql database if necessary, and read the words into a data structure
-(void) loadWords {
    // Get the path to the documents directory and append the databaseName
	NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDir = [documentPaths objectAtIndex:0];
	databasePath = [documentsDir stringByAppendingPathComponent:databaseName];
	
	// Execute the "checkAndCreateDatabase" function
	[self checkAndCreateDatabase];
	
	// Query the database for all riddle records and construct the "riddles" array
	[self readWordsFromDatabase];	
    
}

-(void) checkAndCreateDatabase {
	// Check if the SQL database has already been saved to the users phone, if not then copy it over
	BOOL success;
	
	NSLog(@"checkAndCreateDatabase called");
	
	// Create a FileManager object, we will use this to check the status
	// of the database and to copy it over if required
	NSFileManager *fileManager = [NSFileManager defaultManager];
	
	// Check if the database has already been created in the users filesystem
	success = [fileManager fileExistsAtPath:databasePath];
	
	// If the database already exists then return without doing anything
	if(success) return;
	
	// If not then proceed to copy the database from the application to the users filesystem
	
	// Get the path to the database in the application package
	NSString *databasePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:databaseName];
	
	// Copy the database from the package to the users filesystem
	[fileManager copyItemAtPath:databasePathFromApp toPath:databasePath error:nil];
	
	//[fileManager release];
}

-(void) readWordsFromDatabase {
    
    
    NSLog(@"opening specific words");
    int numWordsLoaded = 0;
    int numSets = 10;
    int numStartWords = 50;
    int wordSetModCounter = 1;
    int modInc = 30;
    
    // the wordArray is the big array containing the words for the data structure
    wordArray = [[NSMutableArray alloc] init];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	
    [userDefaults setBool:YES forKey:@"firstTimeLoadingWords"];
    
    BOOL firstTimeLoadingWords = [userDefaults boolForKey:@"firstTimeLoadingWords"];
    
	// Open the database from the users file system
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK) {
		// Setup the SQL Statement and compile it for faster access
		const char *sqlStatement = "select * from vocab";
		sqlite3_stmt *compiledStatement;
        
        NSLog(@"databaseName: %@, databasePath: %@", databaseName, databasePath);
        
		if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
			// Loop through the results and add them to the feeds array
            NSLog(@"loop through array");
			while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
				// Read the data from the result row
				// Be careful here. We have to specify the correct column indices. 
				// Later, try to change this to be more robust by adjusting the SQL statement a few lines above!!!
				// For retrieving integers, use sqlite3_column_int
				// For retrieving blobs, use sqlite3_column_blob
				// For retrieving unknown values, use sqlite3_column_value
				int aPk = (int) sqlite3_column_int(compiledStatement, 0);				
				
                // load various parts of the word from the database
                NSString *aWord = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
				
                NSString *aSpeechPart = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
				
                NSString *aDefinition = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
				
                NSString *aDifficulty = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 4)];
				
                NSInteger diff = (int) [aDifficulty doubleValue];
				
                int times_viewed = (int) sqlite3_column_int(compiledStatement, 5);
                
                int set_number = (int) sqlite3_column_int(compiledStatement, 6);
				
                NSString *synString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 7)];
                
                NSString *antString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 8)];
				
                NSString *noteString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 9)];
                
                NSString *longDefString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 10)];
                
                numWordsLoaded += 1;
                
                if (firstTimeLoadingWords == YES) {
                    // initialize set numbers for first 50 words (numStartWords = 50)
                    if (numWordsLoaded <= numStartWords * modInc) {
                        // initialize setValue as sets 1 through 10, (numSets = 10)
                        
                        //set_number = (numWordsLoaded % numSets);       
                        
                        if (numWordsLoaded % modInc == 0) {
                            set_number = wordSetModCounter; 
                            
                            if (wordSetModCounter == 10) {
                                set_number = 10;
                                wordSetModCounter = 0;
                            }
                            wordSetModCounter += 1;                            
                            
                            NSLog(@"word loaded: %@, set number is: %d", aWord, set_number);
                        }
                        
                        if (numWordsLoaded == numStartWords) {
                            [userDefaults setBool:NO forKey:@"firstTimeLoadingWords"];
                        }
                    }
                }
                
                // NSLog(@"\nword loaded (%d): %@, speechPart: %@, setNum: %d, \ndef: %@, \nlongDef: %@", numWordsLoaded, aWord, aSpeechPart, set_number, aDefinition, longDefString);
                
                // define a new word
                Word *newWord = [[Word alloc] initWithName:aWord speechPart:aSpeechPart defShort:aDefinition defLong:longDefString synonyms:synString antonyms:antString notes:noteString difficulty:diff timesViewed:times_viewed setNum:set_number realPK:aPk database_sq:database];
                
                newWord.translationArray = [[[NSMutableArray alloc] init] autorelease];
                
                // add the word to the array
                [wordArray addObject:newWord];
                
                [newWord release];
				
			}
            
            // load translations before sorting (wordArray must be initialized)
            [self loadTranslations];
            
            // sort the array using the setNum
            NSSortDescriptor *setNumDescriptorAscending = [[NSSortDescriptor alloc] initWithKey:@"setNumber" ascending:YES];
            [wordArray sortUsingDescriptors:[NSArray arrayWithObject:setNumDescriptorAscending]];
            [setNumDescriptorAscending release];
            
            // try writing a different loop: for loop going through set indices on outside, while loop going through wordArray index on the inside
            if (firstTimeLoadingWords) {
                
                [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"languageInd"];
                
                int numSetsWithExtraSet = numSets + 1;
                // create hashTable (NSDictionary) with set names, indices
                NSMutableArray *keys = [[NSMutableArray alloc] init];
                for (int i=0; i<=numSetsWithExtraSet; i++) {
                    NSString *setIndexKey = [NSString stringWithFormat:@"key%d", i];
                    [keys addObject:setIndexKey];
                }
                
                setMarkerArray = [[NSMutableArray alloc] init];
                
                int counter = 0;
                for (int setIndex = 0; setIndex < (numSets+1); setIndex+=1) {
                    setHashObject *setObj = [[setHashObject alloc] init];
                    NSNumber *currentSet = [NSNumber numberWithInt:setIndex];
                    NSNumber *startIndexInWordArray = [NSNumber numberWithInt:counter];
                    NSNumber *numWordsInSet;
                    
                    int numSetWordsCounter = 0;

                    Word *traverseWord = [wordArray objectAtIndex:counter];
                    int traverseWordSet = [traverseWord.setNumber intValue];
                    while (traverseWordSet == setIndex) {
                        counter += 1;
                        numSetWordsCounter += 1;
                        if (counter < [wordArray count]) {
                            traverseWord = [wordArray objectAtIndex:counter];
                            traverseWordSet = [traverseWord.setNumber intValue];
                        }
                        else {
                            traverseWordSet += 1;
                        }
                    }
                    numWordsInSet = [NSNumber numberWithInt:numSetWordsCounter];
                    
                    setObj.setNumber = currentSet;
                    setObj.startIndexInWordArray = startIndexInWordArray;
                    setObj.numWordsInSet = numWordsInSet;
                    [setMarkerArray addObject:setObj];
                    [setObj release];
                    
                    NSLog(@"setNumber: %d, startIndexInWordArray: %d, numWordsInSet: %d", currentSet.intValue, startIndexInWordArray.intValue, numWordsInSet.intValue);
                }
                
                // add one more setObject (for discard set)
                setHashObject *setObj = [[setHashObject alloc] init];
                NSNumber *currentSet = [NSNumber numberWithInt:numSets+1];
                NSNumber *startIndexInWordArray = [NSNumber numberWithInt:[wordArray count]];
                NSNumber *numWordsInSet = [NSNumber numberWithInt:0];
                setObj.setNumber = currentSet;
                setObj.startIndexInWordArray = startIndexInWordArray;
                setObj.numWordsInSet = numWordsInSet;
                [setMarkerArray addObject:setObj];
                [setObj release];
                
                [keys release];
            
                int backIndex = [wordArray count]-1;
                Word *backTraverseWord = [wordArray objectAtIndex:backIndex];
                while (backIndex >= [wordArray count] - 51) {
                    //NSLog(@"backIndex: %d, backWord: %@, backWordSet: %d", backIndex, backTraverseWord.word, backTraverseWord.setNumber.intValue);
                    backIndex -= 1;
                    backTraverseWord = [wordArray objectAtIndex:backIndex];
                }
            }
        
        }
        // Release the compiled statement from memory
        sqlite3_finalize(compiledStatement);
        
        NSLog(@"num words loaded: %d", numWordsLoaded);
        
        // temporarily make current set index = 1
        currentSetIndex = 0;
        
        // set currentWordArrayIndex down here
        //currentWordArrayIndex = numWordsLoaded - 1;
        currentWordArrayIndex = [self firstWordInSet:currentSetIndex];
    }

    // do not close the database here
    //sqlite3_close(database);	
}

# pragma mark word index stuff
-(Word *) getCurrentWord {
    return [wordArray objectAtIndex:currentWordArrayIndex];
}

-(void) updateCurrentWord {
    // currentWordArrayIndex += 1;
    currentWordArrayIndex = [self randomWordInSet:currentSetIndex];
}

-(void) setCurrentWord:(int) wordIndex {
    currentWordArrayIndex = wordIndex;
}

// returns an index into the wordArray
-(int) firstWordInSet:(int) setIndex {
    setHashObject *setObj = [setMarkerArray objectAtIndex:setIndex];    
    //NSLog(@"getting set %d object from table, based on setIndex %d", [setObj.setNumber intValue], setIndex);
    return [setObj.startIndexInWordArray intValue];
}

// returns an index into the wordArray
-(int) randomWordInSet:(int) setIndex {
    setHashObject *setObj = [setMarkerArray objectAtIndex:setIndex];
    int startIndex = [setObj.startIndexInWordArray intValue];
    int numSetWords = [setObj.numWordsInSet intValue];
    int endIndex = startIndex + numSetWords - 1;
    // NSLog(@"\n\nsetArray: %d, setIndex: %d, numWords: %d, startIndex: %d, endIndex: %d", [setObj.setNumber intValue], setIndex, numSetWords, startIndex, endIndex);
    
    if (numSetWords == 1) {
        return startIndex;
    }
    
    // rv is a U[0,1] random variable
    float rv = [self randomUniformVar];
    
    float addVal = (float) numSetWords * rv;
    int addRandomVal = (int) addVal;
    
    int randomWordIndex = startIndex + addRandomVal;
    
    //NSLog(@"addRandomVal: %d, randomWordIndex: %d, currentWordArrayIndex: %d", addRandomVal, randomWordIndex, currentWordArrayIndex);
    
    if (randomWordIndex > endIndex) {
        randomWordIndex = endIndex;
    }
    else if (randomWordIndex == currentWordArrayIndex) {
        NSLog(@"--> came up with the same index %d, call again", randomWordIndex);
        return [self randomWordInSet:currentSetIndex];
    }
    
    return randomWordIndex;
}

-(void) changeSetsForCurrentWord:(int) newSetIndex {
    Word *currentWord = [[wordArray objectAtIndex:currentWordArrayIndex] retain];
    int oldSetIndex = [currentWord.setNumber intValue];
    
    // if the new set is the same as the old set, return
    if (newSetIndex == oldSetIndex)
        return;
    
    setHashObject *newSetObj = [setMarkerArray objectAtIndex:newSetIndex];
    setHashObject *oldSetObj = [setMarkerArray objectAtIndex:oldSetIndex];
    
    // if there is only one word in the old set, return
    if (oldSetObj.numWordsInSet.intValue == 1) {
        NSLog(@"need to keep one word in each set");
        return;
    }
    
    // remove the word object from the wordArray
    [wordArray removeObject:currentWord];
    
    // decrease the numWords in the old set by 1
    oldSetObj.numWordsInSet = [NSNumber numberWithInt:(oldSetObj.numWordsInSet.intValue - 1)];
    
    //NSLog(@"\n\n\n1 after removing old word from old set, prior to incrementing startIndices:");
    //[self printSetData:oldSetIndex];
    
    // for each of the remaining sets after the oldSet, decrement the startIndex
    for (int setInd=oldSetIndex+1; setInd<[setMarkerArray count]; setInd+=1) {
        setHashObject *set = [setMarkerArray objectAtIndex:setInd];
        set.startIndexInWordArray = 
            [NSNumber numberWithInt:(set.startIndexInWordArray.intValue-1)];
    }
    
    // set the currentWordArrayIndex to another word in the set
    currentWordArrayIndex = [self randomWordInSet:currentSetIndex];
    
    // update setNumber in the newly placed Word
    currentWord.setNumber = [NSNumber numberWithInt:newSetIndex];
    
    newSetObj.numWordsInSet = [NSNumber numberWithInt:(newSetObj.numWordsInSet.intValue + 1)];
    [wordArray insertObject:currentWord atIndex:newSetObj.startIndexInWordArray.intValue];
    [currentWord release];
    
    //NSLog(@"\n\n\n2 after adding old word to new set, prior to incrementing startIndices:");
    //[self printSetData:newSetIndex];
    
    // for each of the remaining sets after the newSet, increment the startIndex
    for (int setInd=newSetIndex+1; setInd<[setMarkerArray count]; setInd+=1) {
        setHashObject *set = [setMarkerArray objectAtIndex:setInd];
        set.startIndexInWordArray = 
            [NSNumber numberWithInt:(set.startIndexInWordArray.intValue+1)];
    }
}

# pragma mark return a setIndex for a hard, med, or easy set
-(int) getSetIndex:(int) difficultyIndicator {
    // difficultyIndicator = 3 --> hard level (sets 8 to 10), 3 sets
    // difficultyIndicator = 2 --> med level (4 to 7), 4 sets
    // difficultyIndicator = 1 --> easy level (1 to 3), 3 sets
    // difficultyIndicator = 0 --> discard  (set 11), 1 set
    int numSetsInDifficulty = 0;
    if (difficultyIndicator == 3 || difficultyIndicator == 1) {
        numSetsInDifficulty = 3;
    }
    else {
        numSetsInDifficulty = 4;
    }
    
    float addNum = numSetsInDifficulty * [self randomUniformVar];
    int addNumInt = (int) addNum;
    
    int setIndex = 0;
    switch (difficultyIndicator) {
        case 3:
            setIndex = 8 + addNumInt;
            break;
        case 2:
            setIndex = 4 + addNumInt;
            break;
        case 1:
            setIndex = 1 + addNumInt;
            break;
        case 0:
            setIndex = 11;
            break;
        default:
            break;
    }
    return setIndex;
}

# pragma print data for set
-(void) printSetData:(int) setNum {
    setHashObject *set = [setMarkerArray objectAtIndex:setNum];
    int startIndex = [set.startIndexInWordArray intValue];
    int numSetWords = [set.numWordsInSet intValue];
    int endIndex = startIndex + numSetWords - 1;
    NSLog(@"\n\nsetIndex: %d, numWords: %d, startIndex: %d, endIndex: %d", setNum, numSetWords, startIndex, endIndex);
    int maxWords = MIN(numSetWords, 10);
    NSLog(@"first 10 or less words in set %d:", set.setNumber.intValue);
    for (int i=0; i<maxWords; i+=1) {
        Word *word = [wordArray objectAtIndex:(startIndex+i)];
        NSLog(@"%d: %@", i, word.word);
    }
}

-(float) randomUniformVar {
    // rv is a U[0,1] random variable
    float rv = (float) random() / RAND_MAX;
    return rv;
}

# pragma mark translations
-(void) loadTranslations {
    
    languageData = [[languageModel alloc] init];
    
    // self.pickerData = array; 
    
    for (int languageIndex = 0; languageIndex<[languageData.languageArray count]; languageIndex+=1 ) {
        
        NSArray *translatedWords = [languageData getTranslationArray:languageIndex];
        
        NSLog(@"wordArray count: %d, translatedWordsArray count: %d", [wordArray count], [translatedWords count]);
        
        for (int i=0; i<[wordArray count]; i+=1 ) {
            Word *currentWord = [wordArray objectAtIndex:i];
            [currentWord.translationArray addObject:[translatedWords objectAtIndex:i]];
            // NSLog(@"word: %@, translation: %@", currentWord.word, [currentWord.translationArray objectAtIndex:0]);
        }
    }
}

@end
