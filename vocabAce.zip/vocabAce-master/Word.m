//
//  Word.m
//  vocabAce
//
//  Created by Paul Yang on 9/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Word.h"

@implementation Word 

@synthesize word, speechPart, defShort, defLong, synString, antString, noteStr, setNumber, diff, timesViewed, aPK, translationArray;

-(id)initWithName:(NSString *)wd  
       speechPart:(NSString*)sp  
         defShort:(NSString *)defS  
          defLong:(NSString *)defL 
         synonyms:(NSString *)synStr
         antonyms:(NSString *)antStr  
            notes:(NSString *)noteSt   
       difficulty:(NSInteger)dif   
      timesViewed:(NSInteger)tv 
           setNum:(int)setNum 
           realPK:(int)real_pk
      database_sq:(sqlite3 *)db
{
    self.word = wd;
    self.speechPart = sp;
    self.defShort = defS;
    self.defLong = defL;
    self.synString = synStr;
    self.antString = antStr;
    self.noteStr = noteSt;
    self.setNumber = [NSNumber numberWithInt:setNum];
    self.diff = dif;
    self.timesViewed = tv;
    self.aPK = real_pk;
    database = db;
    dirty = NO;
    
    return self;
}

// get the definition of the word, depending on whether it's short or long
-(NSString *) getDefText:(int)useShortDef  {
    NSString *rawDefString;
    
    if (useShortDef == 1) 
        rawDefString = defShort;
    else
        rawDefString = defLong;

	NSString *defText = @"";
    NSString *defsWithNewlines = @"";
	NSArray *senses = [rawDefString componentsSeparatedByString:@"$"];
	for (int i=1; i<[senses count]; i++) {
		NSString *meaningStr = [senses objectAtIndex:i];
		NSArray *meaningParts = [meaningStr componentsSeparatedByString:@"&"];
		for (int j=0; j<[meaningParts count]; j++) {
			if (NO) 
				NSLog(@"meaning part %d: %@", j, [meaningParts objectAtIndex:j]);
		}
        
        if (useShortDef == 1) {
            return [meaningParts objectAtIndex:3];
        }
		
		NSString *s_part = [meaningParts objectAtIndex:1];
		NSString *s_part_long;
		if ([s_part isEqualToString:@"v"]) {
			s_part_long = @"verb"; 
		}
		else if ([s_part isEqualToString:@"n"]) {
			s_part_long = @"noun"; 
		}
		else {
			s_part_long = @"adjective"; 
		}
		
        NSString *defWithSentence = [meaningParts objectAtIndex:3]; 
        NSArray *defAndSentence = [defWithSentence componentsSeparatedByString:@"*"]; 
        NSString *defOnly = [defAndSentence objectAtIndex:0]; 
        
        NSString *sentenceOnly; 
        if ([defAndSentence count] > 1) {
            sentenceOnly = [defAndSentence objectAtIndex:1]; 
            defText = [defText stringByAppendingFormat:@"%@ \n",  defOnly];
        }
        else {
            defText = [defText stringByAppendingFormat:@"%@ \n",  defOnly];
        }
        
        NSString *wordColon = [NSString stringWithFormat:@"%@:", word];
        NSArray *defMeanings = [defText componentsSeparatedByString:wordColon];
        
        for (int k=1; k<[defMeanings count]; k++) {
            NSString *currentMeaning = [defMeanings objectAtIndex:k]; 
            if (k < [defMeanings count]-1) {                
                currentMeaning = [currentMeaning substringToIndex:([currentMeaning length]-3)];
            }
            defsWithNewlines = [defsWithNewlines stringByAppendingFormat:@"%@: \n%@ \n\n", word, currentMeaning]; 
        }
	}
	return defsWithNewlines;
}

-(NSString *) getSynonyms {
    NSArray *synParts = [synString componentsSeparatedByString:@"$"];
    int numSyns = 5;
    int numSynsForLoop = MIN([synParts count], numSyns+1);	
    
    NSString *synText = [self getSynText:synParts num_syns_for_loop:numSynsForLoop];
    return synText;
}

-(NSString *) getSynText: (NSArray *) synParts num_syns_for_loop:(int) numSynsForLoop {
	NSString *synText = @"";
	for (int i=1; i<numSynsForLoop; i++) {
		NSString *currentSyn = [synParts objectAtIndex:i];
		if (i==1) {
			synText = [synText stringByAppendingString:currentSyn];
		}
		else {
			synText = [synText stringByAppendingString:@", "];
			synText = [synText stringByAppendingString:currentSyn];
		}
	}
	return synText;
}
@end
