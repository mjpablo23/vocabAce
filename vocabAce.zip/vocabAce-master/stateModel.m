//
//  stateModel.m
//  vocabAce
//
//  Created by Paul Yang on 8/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "stateModel.h"

@implementation stateModel

@synthesize coverVisible, hintTextViewVisible, showingLongDefinition;

- (id) init {
    [super init];
    
    coverVisible = 0;
    hintTextViewVisible = 0;
    showingLongDefinition = 0;
    
    return self;
}

@end
